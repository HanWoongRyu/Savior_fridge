//package com.example.myRefri02;
//
//import android.view.View;
//
//public interface OnItemClickListener {
//    void onItemClick(Adapter.ItemViewHolder holder, View view, int position);
//}
